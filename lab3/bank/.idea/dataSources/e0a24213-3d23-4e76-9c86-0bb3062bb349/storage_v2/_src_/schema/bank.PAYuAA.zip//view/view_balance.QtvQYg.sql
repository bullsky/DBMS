create view view_balance as
  select
    `bank`.`vbank_usercard`.`id`          AS `id`,
    `bank`.`vbank_bankcard`.`card_num`    AS `card_num`,
    `bank`.`vbank_bankcard`.`balance`     AS `balance`,
    `bank`.`vbank_bankcard`.`currency`    AS `currency`,
    `bank`.`vbank_identity`.`name`        AS `name`,
    `bank`.`vbank_identity`.`id_card_num` AS `id_card_num`
  from ((`bank`.`vbank_identity`
    join `bank`.`vbank_bankcard`
      on ((`bank`.`vbank_bankcard`.`identity_id` = `bank`.`vbank_identity`.`id_card_num`))) join `bank`.`vbank_usercard`
      on (((`bank`.`vbank_usercard`.`bank_card_id` = `bank`.`vbank_bankcard`.`card_num`) and
           (`bank`.`vbank_usercard`.`identity_id` = `bank`.`vbank_identity`.`id_card_num`))));

